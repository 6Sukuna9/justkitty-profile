GITHUB PAGES SETUP

1. Create a GitHub repository
2. Upload index.html
3. Go to Settings -> Pages
4. Select:
   Branch: main
   Folder: /root
5. Save
6. Your website will be live in about 1 minute

URL:
https://YOURUSERNAME.github.io/REPOSITORYNAME
